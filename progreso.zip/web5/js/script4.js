function SiguienteEscena(escena){
    //change the background image
    if (escena==1){
        document.body.style.backgroundImage = "url('img/trampa.jpg')";
        document.getElementById("texto").innerHTML = "¡Miras hacia arriba, y descubres con horror que el techo está lleno de pinchos, y están bajando lentamente!<br/>¡Tienes que darte prisa, o morirás!";
        document.getElementById("boton").onclick = function(){SiguienteEscena(2)};
    }
    else if (escena==2){
        //Seguir aquí
    }

}
