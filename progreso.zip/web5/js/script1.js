function DosCaminos(){
    window.location.href="doscaminos.html";
}